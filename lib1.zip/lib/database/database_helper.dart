import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:flutter/material.dart'; // Для Locale
import 'package:period_tracker/l10n/app_localizations.dart';
import '../models/settings.dart';
import '../models/day_note.dart';
import '../models/period_record.dart';
import '../utils/symptoms_provider.dart';

class DatabaseHelper {
  static const _databaseName = "PeriodTracker.db";
  static const _databaseVersion = 11; // Добавляем таблицу симптомов

  static const settingsTable = 'settings';
  static const dayNotesTable = 'day_notes';
  static const periodsTable = 'periods'; // Новая таблица для периодов
  static const symptomsTable = 'symptoms'; // Новая таблица для симптомов

  static Database? _database;

  static Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  static _initDatabase() async {
    String path = join(await getDatabasesPath(), _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  static Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $settingsTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cycleLength INTEGER NOT NULL,
        periodLength INTEGER NOT NULL,
        ovulationDay INTEGER NOT NULL,
        planningMonths INTEGER NOT NULL,
        locale TEXT NOT NULL,
        firstDayOfWeek TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE $dayNotesTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT NOT NULL UNIQUE,
        symptoms TEXT NOT NULL,
        sexualActsCount INTEGER DEFAULT 0
      )
    ''');

    // Новая таблица для периодов
    await db.execute('''
      CREATE TABLE $periodsTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        startDate TEXT NOT NULL,
        endDate TEXT
      )
    ''');

    // Новая таблица для симптомов
    await db.execute('''
      CREATE TABLE $symptomsTable (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE
      )
    ''');

    // Insert default settings
    await db.insert(settingsTable, {
      'cycleLength': 28,
      'periodLength': 5,
      'ovulationDay': 14,
      'planningMonths': 3,
      'locale': 'en',
      'firstDayOfWeek': 'monday',
    });

    // Загружаем локализацию для получения дефолтных симптомов
    final l10n = await AppLocalizations.delegate.load(const Locale('en'));
    final List<String> defaultSymptoms = SymptomsProvider.getDefaultSymptoms(l10n);

    // Добавляем предзаполненные симптомы
    for (final symptom in defaultSymptoms) {
      await db.insert(symptomsTable, {'name': symptom});
    }
  }

  static Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    for (int version = oldVersion + 1; version <= newVersion; version++) {
      switch (version) {
        case 7:
          // Создаем таблицу периодов
          try {
            await db.execute('''
              CREATE TABLE $periodsTable (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                startDate TEXT NOT NULL,
                endDate TEXT
              )
            ''');
            print('Created periods table');
          } catch (e) {
            print('Error creating periods table: $e');
          }
          break;
        case 8:
          // Добавляем столбец locale в таблицу настроек
          try {
            await db.execute('ALTER TABLE $settingsTable ADD COLUMN locale TEXT');
            await db.update(
              settingsTable,
              {'locale': 'en'},
              where: 'locale IS NULL',
            );
            print('Added locale column to settings');
          } catch (e) {
            print('Error adding locale column: $e');
          }
          break;
        case 9:
          // Добавляем столбец firstDayOfWeek в таблицу настроек
          try {
            await db.execute('ALTER TABLE $settingsTable ADD COLUMN firstDayOfWeek TEXT');
            await db.update(
              settingsTable,
              {'firstDayOfWeek': 'monday'},
              where: 'firstDayOfWeek IS NULL',
            );
            print('Added firstDayOfWeek column to settings');
          } catch (e) {
            print('Error adding firstDayOfWeek column: $e');
          }
          break;
        case 10:
          // Добавляем столбец sexualActsCount в таблицу day_notes
          try {
            await db.execute('ALTER TABLE $dayNotesTable ADD COLUMN sexualActsCount INTEGER DEFAULT 0');
            print('Added sexualActsCount column to day_notes');
          } catch (e) {
            print('Error adding sexualActsCount column: $e');
          }
          break;
        case 11:
          // Добавляем таблицу симптомов и предзаполненный набор
          try {
            await db.execute('''
              CREATE TABLE IF NOT EXISTS $symptomsTable (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE
              )
            ''');

            // Загружаем локализацию (по умолчанию английскую) для предзаполненных симптомов
            final l10n = await AppLocalizations.delegate.load(const Locale('en'));
            final List<String> defaultSymptoms = SymptomsProvider.getDefaultSymptoms(l10n);
            
            // Только если таблица пуста, добавляем предзаполненные симптомы
            final List<Map<String, dynamic>> existingSymptoms = await db.query(symptomsTable);
            if (existingSymptoms.isEmpty) {
              for (final symptom in defaultSymptoms) {
                await db.insert(symptomsTable, {'name': symptom});
              }
            }
          } catch (e) {
            // Если возникает ошибка, например, таблица уже существует, игнорируем
          }
          break;
      }
    }
  }

  // Settings methods
  Future<int> updateSettings(Settings settings) async {
    try {
      Database db = await database;
      return await db.update(
        settingsTable,
        settings.toMap(),
        where: 'id = ?',
        whereArgs: [settings.id],
      );
    } catch (e) {
      print('Error updating settings: $e');
      throw Exception('Error updating settings: $e');
    }
  }

  Future<Settings> getSettings() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(settingsTable);
      if (maps.isNotEmpty) {
        return Settings.fromMap(maps[0]);
      }
      throw Exception('No settings found');
    } catch (e) {
      print('Error getting settings: $e');
      throw Exception('Error getting settings: $e');
    }
  }

  // Period Records methods
  Future<int> insertPeriodRecord(PeriodRecord record) async {
    try {
      Database db = await database;
      final result = await db.insert(
        periodsTable,
        record.toMap(),
      );
      print('Successfully saved PeriodRecord: ${record.toMap()}');
      return result;
    } catch (e) {
      print('Error saving period record: $e');
      throw Exception('Error saving period record: $e');
    }
  }

  Future<int> updatePeriodRecord(PeriodRecord record) async {
    try {
      Database db = await database;
      final result = await db.update(
        periodsTable,
        record.toMap(),
        where: 'id = ?',
        whereArgs: [record.id],
      );
      print('Successfully updated PeriodRecord: ${record.toMap()}');
      return result;
    } catch (e) {
      print('Error updating period record: $e');
      throw Exception('Error updating period record: $e');
    }
  }

  Future<int> deletePeriodRecord(int id) async {
    try {
      Database db = await database;
      final result = await db.delete(
        periodsTable,
        where: 'id = ?',
        whereArgs: [id],
      );
      print('Successfully deleted PeriodRecord with id: $id');
      return result;
    } catch (e) {
      print('Error deleting period record: $e');
      throw Exception('Error deleting period record: $e');
    }
  }

  Future<List<PeriodRecord>> getAllPeriodRecords() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(
        periodsTable,
        orderBy: 'startDate DESC',
      );
      return maps.map((map) => PeriodRecord.fromMap(map)).toList();
    } catch (e) {
      print('Error getting all period records: $e');
      throw Exception('Error getting all period records: $e');
    }
  }

  // Получить последний период (самый новый)
  Future<PeriodRecord?> getLastPeriodRecord() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(
        periodsTable,
        orderBy: 'startDate DESC',
        limit: 1,
      );
      if (maps.isNotEmpty) {
        return PeriodRecord.fromMap(maps[0]);
      }
      return null;
    } catch (e) {
      print('Error getting last period record: $e');
      throw Exception('Error getting last period record: $e');
    }
  }

  // Получить активный период (без даты окончания)
  Future<PeriodRecord?> getActivePeriodRecord() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(
        periodsTable,
        where: 'endDate IS NULL',
        orderBy: 'startDate DESC',
        limit: 1,
      );
      if (maps.isNotEmpty) {
        return PeriodRecord.fromMap(maps[0]);
      }
      return null;
    } catch (e) {
      print('Error getting active period record: $e');
      throw Exception('Error getting active period record: $e');
    }
  }

  // DayNote methods (без hasPeriod)
  Future<int> insertOrUpdateDayNote(DayNote note) async {
    try {
      Database db = await database;
      return await db.insert(
        dayNotesTable,
        note.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
    } catch (e) {
      print('Error saving day note: $e');
      throw Exception('Error saving day note: $e');
    }
  }

  Future<DayNote?> getDayNote(DateTime date) async {
    try {
      Database db = await database;
      final formattedDate = DayNote.formatDateForDatabase(date);
      List<Map<String, dynamic>> maps = await db.query(
        dayNotesTable,
        where: 'date = ?',
        whereArgs: [formattedDate],
      );
      
      if (maps.isNotEmpty) {
        return DayNote.fromMap(maps[0]);
      }
      return null;
    } catch (e) {
      print('Error getting day note: $e');
      throw Exception('Error getting day note: $e');
    }
  }

  Future<List<DayNote>> getAllDayNotes() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(dayNotesTable);
      return maps.map((map) => DayNote.fromMap(map)).toList();
    } catch (e) {
      print('Error getting all day notes: $e');
      throw Exception('Error getting all day notes: $e');
    }
  }

  // Symptom methods
  Future<void> insertSymptom(String symptom) async {
    try {
      Database db = await database;
      await db.insert(
        symptomsTable,
        {'name': symptom},
        conflictAlgorithm: ConflictAlgorithm.ignore, // Игнорировать, если симптом уже существует
      );
    } catch (e) {
      print('Error inserting symptom: $e');
      throw Exception('Error inserting symptom: $e');
    }
  }

  Future<List<String>> getAllSymptoms() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(symptomsTable);
      return maps.map((map) => map['name'] as String).toList();
    } catch (e) {
      print('Error getting all symptoms: $e');
      throw Exception('Error getting all symptoms: $e');
    }
  }

  // Метод для отладки симптомов
  Future<void> debugPrintAllSymptoms() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(symptomsTable);
      print('=== ALL SYMPTOM RECORDS ===');
      for (var map in maps) {
        print('Symptom: $map');
      }
      print('=== END SYMPTOM RECORDS ===');
    } catch (e) {
      print('Error debugging symptoms: $e');
    }
  }

  // Метод для отладки
  Future<void> debugPrintAllPeriods() async {
    try {
      Database db = await database;
      List<Map<String, dynamic>> maps = await db.query(periodsTable);
      print('=== ALL PERIOD RECORDS ===');
      for (var map in maps) {
        print('Period: $map');
      }
      print('=== END PERIOD RECORDS ===');
    } catch (e) {
      print('Error debugging periods: $e');
    }
  }
}